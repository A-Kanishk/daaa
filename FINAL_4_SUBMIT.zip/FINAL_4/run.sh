#!/bin/bash
set -e

# ============================================================
#  Brandes' Betweenness Centrality — Execution Script
#  Team 4 | Assignment 1
# ============================================================

echo "============================================================"
echo "  Brandes' Betweenness Centrality — Assignment 1"
echo "============================================================"

# --- Step 1: Compile ---
echo ""
echo "[1/3] Compiling brandes.cpp ..."
g++ -O2 -std=c++17 -o brandes brandes.cpp
echo "      Compilation successful."

# --- Step 2: Download datasets if not present ---
echo ""
echo "[2/3] Checking datasets ..."

download_if_missing() {
    local FILE="$1"
    local URL="$2"
    if [ ! -f "$FILE" ]; then
        echo "      Downloading $FILE ..."
        wget -q "$URL" -O "${FILE}.gz"
        gunzip "${FILE}.gz"
        echo "      Downloaded and extracted $FILE"
    else
        echo "      $FILE already present."
    fi
}

download_if_missing "wiki-Vote.txt"   "https://snap.stanford.edu/data/wiki-Vote.txt.gz"
download_if_missing "email-Enron.txt"  "https://snap.stanford.edu/data/email-Enron.txt.gz"
download_if_missing "as-skitter.txt"   "https://snap.stanford.edu/data/as-skitter.txt.gz"

# --- Step 3: Run on all three datasets ---
echo ""
echo "[3/3] Running Brandes' algorithm on all datasets ..."
echo ""

echo "--- Dataset 1: wiki-Vote ---"
./brandes -top 20 -o results_wiki-Vote.txt wiki-Vote.txt
echo ""

echo "--- Dataset 2: email-Enron ---"
./brandes -top 20 -o results_email-Enron.txt email-Enron.txt
echo ""

echo "--- Dataset 3: as-Skitter (this can take very long) ---"
./brandes -top 20 -o results_as-skitter.txt as-skitter.txt
echo ""

echo "============================================================"
echo "  All runs complete."
echo "  Results saved to:"
echo "    - results_wiki-Vote.txt"
echo "    - results_email-Enron.txt"
echo "    - results_as-skitter.txt"
echo "============================================================"
